from distutils.core import setup

setup(
    name='HeartbeatMonitor',
    version='0.1',
    packages=['heartbeatmonitor'],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read(),
)
