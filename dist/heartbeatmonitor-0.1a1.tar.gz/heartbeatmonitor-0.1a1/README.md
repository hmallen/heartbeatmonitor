# Heartbeat Monitor

Heartbeat monitor with integrated Slack alerts designed for use with multiple programs simultaneously.
